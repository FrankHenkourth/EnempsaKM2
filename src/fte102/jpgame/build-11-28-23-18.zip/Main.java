package fte102.jpgame;

import fte102.jpgame.gui.VentanaPrincipal;

/**
 *
 * @author henko
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new VentanaPrincipal().setVisible(true);
    }
    
}
