package fte102.jpgame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class PanelRender extends JPanel {

    public PanelRender() {
        x = 60;
        y = 0;
        altura=300;
        anchura=300;
        setSize(762, 530);
        setPreferredSize(new Dimension(762, 530));
        setBackground(Color.decode("#bbf"));
    }
    
 int x,y;
 int altura;
 int anchura;     

 private void moveBall() {
  x = x + 2;
  y = y + 2;
 }

 @Override
 public void paint(Graphics g) {
  super.paint(g);
  Graphics2D g2d = (Graphics2D) g;
  

  for (int i = 0; i <= anchura + (anchura); i += 30) {
            g2d.drawLine(i, 0, i, altura+ (anchura));
        }

      for (int i = 0; i <= altura + (anchura); i += 30) {
            g2d.drawLine(0, i, anchura + (anchura), i);
        }
       
  g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
  g2d.fillOval(x, y, 30, 30);
  
 }
}
